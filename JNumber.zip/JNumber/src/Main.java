import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.File;
import java.io.IOException;
import javax.swing.Timer;

public class Main {
    // Constant for the maximum number of guesses allowed
    private static final int MAX_GUESSES = 10;

    // The target number that the player needs to guess
    private static String target;

    private static Clip backgroundMusicClip;

    // Variables to hold Swing components
    private static JTextField textField;
    private static JButton guessButton;
    private static JLabel resultLabel;

    private static void stopBackgroundMusic() {
        if (backgroundMusicClip != null && backgroundMusicClip.isRunning()) {
            backgroundMusicClip.stop();
            backgroundMusicClip.setFramePosition(0); // Reset to the beginning of the music
        }
    }

    // Add this method to load the background music file
    private static void loadBackgroundMusic(String musicFilePath) {
        try {
            File musicFile = new File(musicFilePath);
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(musicFile);
            backgroundMusicClip = AudioSystem.getClip();
            backgroundMusicClip.open(audioInputStream);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    // Main method to start the game
    public static void main(String[] args) {
        // Generate the target number to guess
        target = getTarget();

        // Load the background music file
        loadBackgroundMusic("D:\\Documents\\Extended Java\\Retake\\JNumber\\Music.wav");

        // Start the background music in a separate thread
        BackgroundMusicThread musicThread = new BackgroundMusicThread();
        musicThread.start();

        // Start the Swing GUI
        SwingUtilities.invokeLater(() -> GUI());
    }

    public static String getTarget() {
        Random r = new Random();

        // StringBuilder to store the target number
        StringBuilder targetBuilder = new StringBuilder();

        for (int i = 0; i < 5; i++) {
            // Append a random digit (0 to 9) to the targetBuilder
            targetBuilder.append(r.nextInt(10));
        }

        // Convert the targetBuilder to a String and store it in the target variable
        String target = targetBuilder.toString();

        System.out.println(target);
        return target;
    }

    // Method to handle game over
    private static void handleGameOver() {
        // Disable the guessButton and textField to prevent further input
        guessButton.setEnabled(false);
        textField.setEnabled(false);

        // Stop the background music when the game ends
        stopBackgroundMusic();

        // Show the target number and the game result in the resultLabel
        showTarget();
        resultLabel.setForeground(Color.RED);
        resultLabel.setText("Game Over. The number was: " + target);
    }

    // Method to create and show the Swing GUI for the game
    private static void GUI() {
        // Create a new JFrame to hold the GUI components
        JFrame frame = new JFrame("NOMBRE");
        frame.setPreferredSize(new Dimension(420, 200));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a new JPanel with a FlowLayout to hold the GUI components
        JPanel panel = new JPanel(new FlowLayout());

        // Create a JLabel to display instructions to the player
        JLabel label = new JLabel("Enter your 5-digit number guess!:");

        // Create JTextField for player to input guess
        textField = new JTextField(10);

        // Create a JButton for player to submit guess
        guessButton = new JButton("Guess");

        // Create a JLabel to display the feedback on the player's guess
        resultLabel = new JLabel();

        // Set the font of the resultLabel to bold and size 16
        resultLabel.setFont(new Font("Helvetica", Font.BOLD, 17));

        // Create a JLabel to display the number of attempts made by the player
        JLabel guessesLabel = new JLabel("Attempts: 0");

        // Create a JLabel to display the timer
        JLabel timerLabel = new JLabel("Time: 1:00");
        timerLabel.setFont(new Font("Helvetica", Font.BOLD, 23));

        // Add the timerLabel to the panel
        panel.add(timerLabel);

        // Create a Timer to update the timer every second (1000 milliseconds)
        int initialTime = 60; // 60 seconds = 1 minute
        Timer timer = new Timer(1000, new ActionListener() {
            int timeLeft = initialTime;

            @Override
            public void actionPerformed(ActionEvent e) {
                timeLeft--;
                if (timeLeft >= 0) {
                    int minutes = timeLeft / 60;
                    int seconds = timeLeft % 60;
                    timerLabel.setText("Time: " + String.format("%d:%02d", minutes, seconds));
                } else {
                    // Time's up, stop the timer and trigger game over
                    ((Timer) e.getSource()).stop();
                    handleGameOver();
                }
            }
        });

        // Start the timer
        timer.start();

        // Import GUI Components
        panel.add(label);
        panel.add(textField);
        panel.add(guessButton);
        panel.add(resultLabel);
        panel.add(guessesLabel);

        // Background colour
        panel.setBackground(Color.ORANGE);

        frame.getContentPane().add(panel);
        frame.pack();
        frame.setLocationRelativeTo(null);

        // Make the Frame visible
        frame.setVisible(true);

        // Add an ActionListener
        guessButton.addActionListener(new ActionListener() {
            // Initialize variables to track remaining guesses and number of attempts
            int remainingGuesses = MAX_GUESSES;
            int NumberOfGuesses = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the player's guess from the textField
                String playerGuess = textField.getText();
                // Check if the game is already over (time is up)
                if (!guessButton.isEnabled()) {
                    return;
                }

                if (!Validation(playerGuess)) {
                    resultLabel.setText("Please Enter a 5 Digit Number");
                    return;
                }

                // Get the feedback on the player's guess using the UpDown() method
                String feedback = UpDown(playerGuess);

                // Set the feedback as the text of the resultLabel
                resultLabel.setText(feedback);

                // Decrement the remainingGuesses and increment the numberOfGuesses
                remainingGuesses--;
                NumberOfGuesses++;

                // Update the guessesLabel to display the number of attempts made by the player
                guessesLabel.setText("Attempts: " + NumberOfGuesses + "/10");

                // Check if the player guessed the correct number or ran out of guesses
                if (playerGuess.equals(target) || remainingGuesses == 0) {
                    // Disable the guessButton and textField to prevent further input
                    guessButton.setEnabled(false);
                    textField.setEnabled(false);
                    // Stop the background music when the game ends
                    stopBackgroundMusic();

                    // Show the target number and the game result in the resultLabel
                    showTarget();
                    if (playerGuess.equals(target)) {
                        resultLabel.setForeground(Color.BLUE);
                        resultLabel.setText("Level Complete!!!");
                    } else {
                        resultLabel.setForeground(Color.RED);
                        resultLabel.setText("No Attempts left! The number was: " + target);
                    }
                }

                // Clear the textField and request focus to input a new guess
                if (!playerGuess.equals(target) && remainingGuesses > 0) {
                    textField.setText("");
                    textField.requestFocus();
                }
            }
        });
    }

    // Validates what the user in entering and ensures it is only numbers
    private static boolean Validation(String playerGuess) {
        // This checks if the guess has only 5 digits
        return playerGuess.matches("\\d{1,5}");
    }

    // This section displays the arrows after each guess to show if each digit in the sequence needs to be higher or lower
    private static String UpDown(String guess) {
        // StringBuilder to store the feedback
        StringBuilder feedback = new StringBuilder();

        // Loop through each digit of the guess and compare with the corresponding digit of the target
        for (int i = 0; i < 5; i++) {
            int digitGuess = Character.getNumericValue(guess.charAt(i));
            int digitTarget = Character.getNumericValue(target.charAt(i));
            if (digitGuess < digitTarget) {
                feedback.append("↑"); //  ↑ means the guess needs to be higher
            } else if (digitGuess > digitTarget) {
                feedback.append("↓"); //  ↓ means the guess needs to be lower
            } else {
                feedback.append(digitGuess); // Append the digit if it matches
            }
        }

        // Convert the feedback StringBuilder to a String and return it
        return feedback.toString();
    }

    private static void showTarget() {
        System.out.println("Target: " + target);
    }

    // Static nested class to loop the  background music
    private static class BackgroundMusicThread extends Thread {
        @Override
        public void run() {
            if (backgroundMusicClip != null) {
                backgroundMusicClip.loop(Clip.LOOP_CONTINUOUSLY); // Loop the background music continuously
            }
        }
    }
}
